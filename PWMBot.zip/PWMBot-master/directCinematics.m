function [PosX,PosY]=directCinematics(motorPos,motorPos)
