function [a] = connectArduino(puerto)
a=arduino(puerto);
end
